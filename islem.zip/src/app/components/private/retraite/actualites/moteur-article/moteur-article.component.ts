import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-moteur-article',
  templateUrl: './moteur-article.component.html',
  styleUrls: ['./moteur-article.component.scss']
})
export class MoteurArticleComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
