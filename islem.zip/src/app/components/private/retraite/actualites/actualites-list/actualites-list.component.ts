import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-actualites-list',
  templateUrl: './actualites-list.component.html',
  styleUrls: ['./actualites-list.component.scss']
})
export class ActualitesListComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
