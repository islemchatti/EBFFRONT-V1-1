import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-articledash',
  templateUrl: './articledash.component.html',
  styleUrls: ['./articledash.component.scss']
})
export class ArticledashComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
