import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-reservationdash',
  templateUrl: './reservationdash.component.html',
  styleUrls: ['./reservationdash.component.scss']
})
export class ReservationdashComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
