import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ReservationdashComponent } from './reservationdash.component';

describe('ReservationdashComponent', () => {
  let component: ReservationdashComponent;
  let fixture: ComponentFixture<ReservationdashComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ReservationdashComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ReservationdashComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
