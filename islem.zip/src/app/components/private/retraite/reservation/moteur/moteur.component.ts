import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-moteur',
  templateUrl: './moteur.component.html',
  styleUrls: ['./moteur.component.scss']
})
export class MoteurComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
