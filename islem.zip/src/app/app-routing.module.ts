import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ActualitesListComponent } from './components/private/retraite/actualites/actualites-list/actualites-list.component';
import { ArticledashComponent } from './components/private/retraite/article/articledash/articledash.component';

import { MoteurComponent } from './components/private/retraite/reservation/moteur/moteur.component';
import { Section1Component } from './components/private/retraite/reservation/moteur/section1/section1.component';
import { ReservationdashComponent } from './components/private/retraite/reservation/reservationdash/reservationdash.component';
import { DashboardComponent } from './components/private/shared/dashboard/dashboard.component';
import { RegisterComponent } from './components/public/register/register.component';

const routes: Routes = [
  {
    path:"dashboard",
    component: DashboardComponent
  },
  {
    path:"register",
    component:RegisterComponent
  },
  {
    path:"section1",
    component:Section1Component
  },
  {
    path:"article",
    component: ArticledashComponent
  },
  {
    path:"retraite",
    children:
    [
      {
        path:"actualites",
        component:ActualitesListComponent
      },
      {
        path:"reservation",
        component:ReservationdashComponent
      }
     
      

    ]
  },
]

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }